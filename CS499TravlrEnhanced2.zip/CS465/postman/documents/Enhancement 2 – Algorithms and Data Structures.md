# Enhancement 2 – Algorithms and Data Structures

---

## Artifact

**Travlr Getaways** — Full-stack web application  
*Originally developed in CS-465: Full Stack Development I and II*

---

## Overview

The Travlr Getaways application allows users to view travel packages and enables administrators to manage trip information through a web-based interface. While the original application provided basic trip retrieval functionality, users had **limited ability to efficiently locate travel packages** that matched their interests and preferences — requiring manual browsing of all available trips.

---

## Enhancement Description

For this enhancement, the application's data-processing capabilities were expanded by implementing **advanced search, filtering, and sorting functionality** across both the backend API and the Angular frontend.

### Key Changes

**Backend (Node.js / Express)**
- Added a new `GET /api/trips/search` endpoint to the backend API
- Implemented a keyword search algorithm across `name`, `resort`, `description`, and `code` fields
- Added trip length filtering (`minDays` / `maxDays`) with parsing for `"N days/nights"` format
- Added price range filtering (`minPrice` / `maxPrice`) with handling for comma-formatted stored values
- Implemented sorting by name (alphabetical), length (numeric days), or price — ascending or descending

**Angular Frontend**
- Added a `searchTrips()` method to `TripDataService` using `HttpParams` to communicate with the new API endpoint
- Updated `TripListingComponent` with a search panel UI and `onSearch()` / `onReset()` methods
- Added `FormsModule` for two-way data binding on search and filter controls

**Testing**
- Added a *Search Trips* Postman request with a full test suite to the Travlr Getaways API collection

---

## Skills Demonstrated

- **Algorithm design** — building a multi-criteria search algorithm that evaluates user-provided input against stored data
- **Data filtering and sorting** — implementing range-based filters and multi-field sort logic
- **Full-stack development** — coordinating changes across a Node.js/Express backend and an Angular frontend
- **Problem solving and optimization** — improving data retrieval efficiency to reduce unnecessary browsing
- **API design** — creating a well-structured, parameterized search endpoint
- **Testing** — writing a Postman test suite to validate search endpoint behavior

---

## Course Outcomes

### Course Outcome 3 — Algorithmic Principles

> *Design and evaluate computing solutions that solve a given problem using algorithmic principles and computer science practices and standards appropriate to its solution.*

This enhancement directly supports Outcome 3 by applying algorithmic principles to a real-world problem. The search, filtering, and sorting logic demonstrates the design and implementation of efficient data-processing algorithms within a production-style full-stack application.

### Course Outcome 4 — Modern Tools and Techniques

> *Demonstrate an ability to use well-founded and innovative techniques, skills, and tools in computing practices for the purpose of implementing computer solutions that deliver value.*

This enhancement supports Outcome 4 through the use of modern software development tools and techniques, including the Express.js framework for API development, Angular's reactive data services, `HttpParams` for structured query construction, and Postman for API testing and validation.
