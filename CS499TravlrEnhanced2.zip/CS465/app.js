/**
 * app.js
 * Entry point for the Travlr Getaways Express application.
 * Configures middleware, view engine, static files, routes,
 * and starts the HTTP server.
 */
require('dotenv').config(); // Load .env variables into process.env before anything else
const express = require('express');
const path = require('path');
const hbs = require('hbs');
const mongoose = require('mongoose');

// Initialize Express
const app = express();
const PORT = process.env.PORT || 3000;

// ⭐ REQUIRED FOR POSTMAN + ANGULAR ⭐
app.use(express.json());

// CORS — allow Angular SPA (port 4200) to call this API (port 3000)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Connect to MongoDB via Mongoose
require('./app_api/models/db');

// Set up Handlebars as the view engine
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

// Register partials
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Frontend routes
const indexRouter = require('./app_server/routes/index');
const roomsRouter = require('./app_server/routes/rooms');
const travelRouter = require('./app_server/routes/travel');
const mealsRouter = require('./app_server/routes/meals');
const newsRouter = require('./app_server/routes/news');
const contactRouter = require('./app_server/routes/contact');
const aboutRouter = require('./app_server/routes/about');

// API routes
const apiRouter = require('./app_api/routes/index');

// Use routes
app.use('/', indexRouter);
app.use('/rooms', roomsRouter);
app.use('/travel', travelRouter);
app.use('/meals', mealsRouter);
app.use('/news', newsRouter);
app.use('/contact', contactRouter);
app.use('/about', aboutRouter);

// API
app.use('/api', apiRouter);

// 404 catch-all — must be registered after all other routes
app.use((req, res) => {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
});

/**
 * Global error-handling middleware.
 * Catches any error passed via next(err) from routes or middleware.
 * Returns a JSON error response so the client always gets structured output.
 *
 * @param {Error}    err  - The error object forwarded by next(err)
 * @param {object}   req  - Express request object
 * @param {object}   res  - Express response object
 * @param {Function} next - Express next middleware function (required for 4-arg signature)
 */
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.stack || err.message);
  const status = err.status || 500;
  res.status(status).json({
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
