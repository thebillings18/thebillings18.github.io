/**
 * app_api/routes/index.js
 * REST API route definitions for the Travlr Getaways backend.
 *
 * All routes are mounted under /api in app.js (e.g. POST /api/login).
 *
 * Authorization model:
 *  - Public endpoints (no token required): GET /trips, GET /trips/:tripCode,
 *    POST /register, POST /login
 *  - Protected endpoints (valid JWT required via authenticate middleware):
 *    POST /trips, PUT /trips/:tripCode, DELETE /trips/:tripCode,
 *    DELETE /trips/id/:id
 *  - Reservation endpoints (all protected — require valid JWT):
 *    GET    /reservations            → list own reservations
 *    POST   /reservations            → create a reservation
 *    GET    /reservations/:id        → view a single reservation
 *    PUT    /reservations/:id        → modify a reservation
 *    DELETE /reservations/:id        → cancel a reservation
 *
 * Route ordering note: /trips/id/:id is declared before /trips/:tripCode
 * so that Express matches the literal segment "id" before treating it as
 * a dynamic :tripCode parameter.
 */
const express = require('express');
const router = express.Router();
const tripsController        = require('../controllers/trips');
const authController         = require('../controllers/authentication');
const reservationsController = require('../controllers/reservations');
const { authenticate } = require('../middleware/authenticate');
const { isAdmin }      = require('../middleware/isAdmin');

// Ensure the Reservation model is registered with Mongoose before any
// controller that references mongoose.model('reservations') is called.
require('../models/reservation');

// ── Auth endpoints (public) ──────────────────────────────────────────────────
router.post('/register', authController.register);
router.post('/login',    authController.login);

// ── Trip collection endpoints ────────────────────────────────────────────────
router
  .route('/trips')
  .get(tripsController.tripsList)               // Public: browse all trips
  .post(authenticate, tripsController.tripsAddTrip); // Protected: create a trip

// Search/filter/sort trips — must be declared before /:tripCode so that the
// literal segment "search" is not captured as a dynamic trip code parameter.
// Public: no authentication required.
// Supported query params: q, minDays, maxDays, minPrice, maxPrice, sortBy, sortOrder
router
  .route('/trips/search')
  .get(tripsController.tripsSearch);

// Delete by MongoDB _id — needed for trips that were imported without a code value.
// Must be declared before /:tripCode to prevent "id" being captured as a trip code.
router
  .route('/trips/id/:id')
  .delete(authenticate, tripsController.tripsDeleteById);

// ── Single trip endpoints (keyed by trip code) ───────────────────────────────
router
  .route('/trips/:tripCode')
  .get(tripsController.tripReadOne)                      // Public: view one trip
  .put(authenticate, tripsController.tripsUpdateTrip)    // Protected: update a trip
  .delete(authenticate, tripsController.tripsDeleteTrip); // Protected: delete a trip

// ── Reservation endpoints (all protected) ────────────────────────────────────
// Collection-level: list own reservations / create a new one
router
  .route('/reservations')
  .get(authenticate,  reservationsController.reservationsList)    // GET  own history
  .post(authenticate, reservationsController.reservationsCreate); // POST new booking

// Admin-only: confirm a pending reservation.
// Declared BEFORE /:id so Express does not treat "confirm" as an id value.
router
  .route('/reservations/:id/confirm')
  .put(authenticate, isAdmin, reservationsController.reservationsConfirm); // Admin: confirm

// Document-level: view / modify / cancel a single reservation by _id
router
  .route('/reservations/:id')
  .get(authenticate,    reservationsController.reservationReadOne)  // GET  one
  .put(authenticate,    reservationsController.reservationsUpdate)  // PUT  modify
  .delete(authenticate, reservationsController.reservationsCancel); // DELETE cancel

module.exports = router;
