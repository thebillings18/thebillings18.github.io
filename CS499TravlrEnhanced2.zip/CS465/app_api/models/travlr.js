/**
 * travlr.js
 * Mongoose model for the 'trips' collection.
 *
 * Represents a single travel package offered by Travlr Getaways.
 * The 'code' field acts as the application-level unique identifier used
 * in API routes (e.g. GET /api/trips/:tripCode). MongoDB's _id is used
 * for the tripsDeleteById endpoint when a trip has no code.
 */
const mongoose = require('mongoose');

/**
 * Schema definition for a trip document.
 *
 * Field notes:
 *  - code:       Short alphanumeric identifier (e.g. "GAL123"). Indexed for fast
 *                lookups. Not marked required so seed data without codes can be imported.
 *  - name:       Display name shown in the SPA and customer-facing site. The only
 *                required field — a trip must have a name to be meaningful.
 *  - start:      Departure date stored as a Date for potential future sorting/filtering.
 *  - perPerson:  Stored as String to preserve formatting (e.g. "1,895") without
 *                introducing floating-point rounding concerns in display logic.
 */
const tripSchema = new mongoose.Schema({
    code:        { type: String, index: true },
    name:        { type: String, required: true, index: true },
    length:      { type: String },
    start:       { type: Date },
    resort:      { type: String },
    perPerson:   { type: String },
    image:       { type: String },
    description: { type: String }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
