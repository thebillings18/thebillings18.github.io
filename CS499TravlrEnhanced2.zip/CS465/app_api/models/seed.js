/**
 * seed.js
 * One-time database seeding script for the Travlr Getaways API.
 *
 * Wipes the 'trips' collection and repopulates it from data/trips.json.
 * Run manually from the project root when you need to reset trip data:
 *
 *   node app_api/models/seed.js
 *
 * WARNING: deleteMany({}) removes ALL existing trip documents before inserting.
 * Do not run this against a production database unless a full reset is intended.
 *
 * Requires JWT_SECRET to be set in the environment (loaded via db.js → app startup).
 */
const mongoose = require('./db');
require('./travlr');

const Trip = mongoose.model('trips');

const fs = require('fs');

// Load seed data synchronously — acceptable here because this is a CLI script,
// not a request handler, so blocking I/O does not affect server responsiveness.
const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

/**
 * Clears the trips collection and inserts all records from the seed file.
 * Uses deleteMany + insertMany rather than individual upserts to guarantee
 * a clean slate regardless of what was previously in the database.
 */
const seedDB = async () => {
  await Trip.deleteMany({});
  await Trip.insertMany(trips);
};

seedDB().then(async () => {
  await mongoose.connection.close();
  process.exit(0);
});
