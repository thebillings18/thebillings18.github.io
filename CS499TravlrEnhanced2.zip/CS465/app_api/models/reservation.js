/**
 * reservation.js
 * Mongoose model for the 'reservations' collection.
 *
 * Represents a booking made by an authenticated user for a specific trip.
 * Each reservation is linked to a User (by userId) and a Trip (by tripCode).
 *
 * Status lifecycle:
 *   pending  → confirmed → cancelled
 *             └──────────→ cancelled
 */
const mongoose = require('mongoose');

/**
 * Schema definition for a reservation document.
 *
 * Field notes:
 *  - userId:       ObjectId reference to the User who made the booking.
 *                  Indexed for fast per-user history queries.
 *  - tripCode:     The trip's application-level code (mirrors Trip.code).
 *                  Stored as a string so reservations survive trip document
 *                  updates without requiring a populate.
 *  - tripName:     Denormalised trip name for display without a join.
 *  - guests:       Number of travellers included in this booking (min 1).
 *  - specialRequests: Free-text field for dietary needs, accessibility, etc.
 *  - status:       Workflow state — 'pending' on creation, then 'confirmed'
 *                  or 'cancelled' by admin or the user.
 *  - createdAt /
 *    updatedAt:    Managed automatically by the { timestamps: true } option.
 */
const reservationSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
      required: true,
      index: true
    },
    tripCode: {
      type: String,
      required: true,
      index: true
    },
    tripName: {
      type: String,
      required: true
    },
    guests: {
      type: Number,
      required: true,
      min: [1, 'At least one guest is required']
    },
    specialRequests: {
      type: String,
      default: ''
    },
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'cancelled'],
      default: 'pending'
    }
  },
  { timestamps: true }
);

const Reservation = mongoose.model('reservations', reservationSchema);
module.exports = Reservation;
