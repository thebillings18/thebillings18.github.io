/**
 * db.js
 * Manages the MongoDB connection lifecycle for the Travlr Getaways API.
 *
 * Responsibilities:
 *  - Establishes the Mongoose connection using DB_HOST from the environment
 *  - Logs connection state changes (connected, error, disconnected)
 *  - Registers all Mongoose models so they are available application-wide
 *  - Handles graceful shutdown on SIGINT, SIGTERM, and SIGUSR2 (nodemon restart)
 *  - Works around a Windows limitation where readline must proxy SIGINT from stdin
 *
 * Usage: require this module once in app.js before any route that needs the DB.
 * It exports the mongoose instance so callers can access connection state if needed.
 */
const mongoose = require('mongoose');
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;
const readLine = require('readline');

/**
 * Initiates the Mongoose connection with a 1-second delay.
 * The delay gives the process time to finish bootstrapping before
 * attempting to reach the database, reducing spurious connection errors
 * during startup on slower machines.
 */
const connect = () => {
    setTimeout(() => mongoose.connect(dbURI, {}), 1000);
};

mongoose.connection.on('connected', () => {
    console.log(`Mongoose connected to ${dbURI}`);
});
mongoose.connection.on('error', err => {
    console.log('Mongoose connection error:', err);
});
mongoose.connection.on('disconnected', () => {
    console.log('Mongoose disconnected');
});

// On Windows, the readline interface is required to surface Ctrl+C as a SIGINT
// event because Node.js does not receive SIGINT directly from the terminal on that platform.
if (process.platform === 'win32') {
    const r1 = readLine.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    r1.on('SIGINT', () => {
        process.emit("SIGINT");
    });
}

/**
 * Closes the Mongoose connection cleanly before the process exits.
 * Called by each signal handler below with a descriptive message for logging.
 *
 * @param {string} msg - Human-readable reason for the shutdown (used in log output)
 */
const gracefulShutdown = (msg) => {
    mongoose.connection.close(() => {
        console.log(`Mongoose disconnected through ${msg}`);
    });
};

// nodemon sends SIGUSR2 when restarting; re-emit after closing so nodemon can proceed
process.once('SIGUSR2', () => {
    gracefulShutdown('nodemon restart');
    process.kill(process.pid, 'SIGUSR2');
});
process.on('SIGINT', () => {
    gracefulShutdown('app termination');
    process.exit(0);
});
process.on('SIGTERM', () => {
    gracefulShutdown('app shutdown');
    process.exit(0);
});

connect();

// Registering models here ensures they are available to mongoose.model() calls
// anywhere in the application without requiring the schema files individually.
require('./travlr');
require('./user');
module.exports = mongoose;
