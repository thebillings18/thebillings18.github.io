/**
 * user.js
 * Mongoose model for the 'users' collection.
 *
 * Stores credentials for the Travlr Getaways SPA. Passwords are never
 * stored in plaintext — only the bcrypt hash is persisted. The plain-text
 * password exists only in memory during the register/login request lifecycle.
 *
 * Authentication flow:
 *  1. Registration: caller invokes setPassword(plainText) → bcrypt hash stored in 'hash'
 *  2. Login: caller invokes validPassword(plainText) → bcrypt compare against stored hash
 *  3. On success, authentication.js issues a signed JWT that includes the user's role
 *     (see app_api/controllers/authentication.js)
 *
 * Role model:
 *  - 'user'  (default) — can create, view, update, and cancel their own reservations
 *  - 'admin'           — can additionally confirm any reservation and view all bookings
 *
 * Promoting a user to admin is done directly in MongoDB (or via a future admin API):
 *   db.users.updateOne({ email: 'you@example.com' }, { $set: { role: 'admin' } })
 */
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

/**
 * Schema definition for a user document.
 *
 * Field notes:
 *  - email:  Stored lowercase (enforced by schema) to ensure case-insensitive
 *            uniqueness. The unique index prevents duplicate registrations.
 *  - hash:   bcrypt hash of the user's password. Required so a user document
 *            cannot be saved without a password having been set.
 *  - role:   Access level. Defaults to 'user'. Set to 'admin' to grant elevated
 *            privileges (confirm reservations, view all bookings).
 */
const userSchema = new mongoose.Schema({
  name:  { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  hash:  { type: String, required: true },
  role:  { type: String, enum: ['user', 'admin'], default: 'user' }
});

/**
 * Instance method: hashes a plain-text password and stores the result on this document.
 * Must be called before save() when creating a new user.
 *
 * @param {string} password - The plain-text password supplied by the user
 */
userSchema.methods.setPassword = function (password) {
  this.hash = bcrypt.hashSync(password, 10);
};

/**
 * Instance method: verifies a plain-text password against the stored bcrypt hash.
 * Used during login to authenticate without ever decrypting the stored hash.
 *
 * @param {string} password - The plain-text password to verify
 * @returns {boolean} True if the password matches the stored hash; false otherwise
 */
userSchema.methods.validPassword = function (password) {
  return bcrypt.compareSync(password, this.hash);
};

const User = mongoose.model('users', userSchema);
module.exports = User;
