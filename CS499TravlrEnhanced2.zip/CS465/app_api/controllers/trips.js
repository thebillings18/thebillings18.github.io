const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

/**
 * Allowed fields for trip create/update operations.
 * Acts as an explicit allow-list to prevent mass-assignment of unexpected fields.
 * @type {string[]}
 */
const TRIP_ALLOWED_FIELDS = ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description'];

/**
 * Extracts only the allowed fields from a request body object.
 * Any keys not in TRIP_ALLOWED_FIELDS are silently dropped.
 *
 * @param {object} body - Raw request body from Express
 * @returns {object} Sanitised object containing only permitted fields
 */
const sanitiseTripBody = (body) => {
  return TRIP_ALLOWED_FIELDS.reduce((acc, field) => {
    if (body[field] !== undefined) acc[field] = body[field];
    return acc;
  }, {});
};

/**
 * GET /api/trips
 * Returns all trips from the database.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find();
    res.status(200).json(trips);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * GET /api/trips/:tripCode
 * Returns a single trip matching the given trip code.
 *
 * @param {object} req            - Express request object
 * @param {string} req.params.tripCode - The unique trip code to look up
 * @param {object} res            - Express response object
 */
const tripReadOne = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode });
    if (trip) {
      res.status(200).json(trip);
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * POST /api/trips
 * Creates and saves a new trip. Only allow-listed fields are accepted.
 *
 * @param {object} req      - Express request object
 * @param {object} req.body - Trip data from the request body
 * @param {object} res      - Express response object
 */
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = new Trip(sanitiseTripBody(req.body));
    const trip = await newTrip.save();
    res.status(201).json(trip);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

/**
 * PUT /api/trips/:tripCode
 * Updates an existing trip identified by trip code. Only allow-listed fields are applied.
 *
 * @param {object} req            - Express request object
 * @param {string} req.params.tripCode - The unique trip code to update
 * @param {object} req.body       - Updated trip fields
 * @param {object} res            - Express response object
 */
const tripsUpdateTrip = async (req, res) => {
  try {
    const updatedTrip = await Trip.findOneAndUpdate(
      { code: req.params.tripCode },
      sanitiseTripBody(req.body),
      { new: true, runValidators: true }
    );
    if (updatedTrip) {
      res.status(200).json(updatedTrip);
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

/**
 * DELETE /api/trips/:tripCode
 * Deletes a trip identified by its trip code.
 *
 * @param {object} req            - Express request object
 * @param {string} req.params.tripCode - The unique trip code to delete
 * @param {object} res            - Express response object
 */
const tripsDeleteTrip = async (req, res) => {
  try {
    const deletedTrip = await Trip.findOneAndDelete({ code: req.params.tripCode });
    if (deletedTrip) {
      res.status(204).send();
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(400).json({ message: 'Error deleting trip', error: error.message });
  }
};

/**
 * DELETE /api/trips/id/:id
 * Deletes a trip by its MongoDB ObjectId. Useful for trips that have no trip code.
 *
 * @param {object} req       - Express request object
 * @param {string} req.params.id - The MongoDB _id of the trip to delete
 * @param {object} res       - Express response object
 */
const tripsDeleteById = async (req, res) => {
  try {
    const deletedTrip = await Trip.findByIdAndDelete(req.params.id);
    if (deletedTrip) {
      res.status(204).send();
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(400).json({ message: 'Error deleting trip', error: error.message });
  }
};

/**
 * GET /api/trips/search
 * Searches, filters, and sorts trips based on optional query parameters.
 *
 * Query parameters (all optional):
 *  - q          {string}  Keyword matched case-insensitively against name, resort,
 *                         description, and code fields.
 *  - minDays    {number}  Minimum trip length in days (inclusive). Parsed from the
 *                         "N days" / "N nights" format stored in the length field.
 *  - maxDays    {number}  Maximum trip length in days (inclusive).
 *  - minPrice   {number}  Minimum per-person price (inclusive). Strips commas before
 *                         parsing so stored values like "1,895" are handled correctly.
 *  - maxPrice   {number}  Maximum per-person price (inclusive).
 *  - sortBy     {string}  Sort field: "name" | "length" | "price". Defaults to "name".
 *  - sortOrder  {string}  Sort direction: "asc" | "desc". Defaults to "asc".
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const tripsSearch = async (req, res) => {
  try {
    // ── 1. Fetch all trips from the database ──────────────────────────────────
    let trips = await Trip.find().lean();

    // ── 2. Keyword search ─────────────────────────────────────────────────────
    const { q, minDays, maxDays, minPrice, maxPrice, sortBy = 'name', sortOrder = 'asc' } = req.query;

    if (q && q.trim() !== '') {
      const keyword = q.trim().toLowerCase();
      trips = trips.filter((trip) => {
        return (
          (trip.name        && trip.name.toLowerCase().includes(keyword))        ||
          (trip.resort      && trip.resort.toLowerCase().includes(keyword))      ||
          (trip.description && trip.description.toLowerCase().includes(keyword)) ||
          (trip.code        && trip.code.toLowerCase().includes(keyword))
        );
      });
    }

    // ── 3. Trip-length filter ─────────────────────────────────────────────────
    // The length field is stored as a human-readable string, e.g. "8 days" or
    // "10 nights". Extract the leading integer for numeric comparison.
    const parseDays = (lengthStr) => {
      if (!lengthStr) return NaN;
      const match = lengthStr.match(/(\d+)/);
      return match ? parseInt(match[1], 10) : NaN;
    };

    if (minDays !== undefined) {
      const min = parseInt(minDays, 10);
      if (!isNaN(min)) {
        trips = trips.filter((trip) => {
          const days = parseDays(trip.length);
          return !isNaN(days) && days >= min;
        });
      }
    }

    if (maxDays !== undefined) {
      const max = parseInt(maxDays, 10);
      if (!isNaN(max)) {
        trips = trips.filter((trip) => {
          const days = parseDays(trip.length);
          return !isNaN(days) && days <= max;
        });
      }
    }

    // ── 4. Price filter ───────────────────────────────────────────────────────
    // perPerson is stored as a String (e.g. "1,895"). Strip commas before parsing.
    const parsePrice = (priceStr) => {
      if (!priceStr) return NaN;
      return parseFloat(String(priceStr).replace(/,/g, ''));
    };

    if (minPrice !== undefined) {
      const min = parseFloat(minPrice);
      if (!isNaN(min)) {
        trips = trips.filter((trip) => {
          const price = parsePrice(trip.perPerson);
          return !isNaN(price) && price >= min;
        });
      }
    }

    if (maxPrice !== undefined) {
      const max = parseFloat(maxPrice);
      if (!isNaN(max)) {
        trips = trips.filter((trip) => {
          const price = parsePrice(trip.perPerson);
          return !isNaN(price) && price <= max;
        });
      }
    }

    // ── 5. Sorting ────────────────────────────────────────────────────────────
    const direction = sortOrder === 'desc' ? -1 : 1;

    trips.sort((a, b) => {
      if (sortBy === 'length') {
        const daysA = parseDays(a.length);
        const daysB = parseDays(b.length);
        // Push trips with unparseable lengths to the end regardless of direction
        if (isNaN(daysA) && isNaN(daysB)) return 0;
        if (isNaN(daysA)) return 1;
        if (isNaN(daysB)) return -1;
        return (daysA - daysB) * direction;
      }

      if (sortBy === 'price') {
        const priceA = parsePrice(a.perPerson);
        const priceB = parsePrice(b.perPerson);
        if (isNaN(priceA) && isNaN(priceB)) return 0;
        if (isNaN(priceA)) return 1;
        if (isNaN(priceB)) return -1;
        return (priceA - priceB) * direction;
      }

      // Default: sort alphabetically by name
      const nameA = (a.name || '').toLowerCase();
      const nameB = (b.name || '').toLowerCase();
      if (nameA < nameB) return -1 * direction;
      if (nameA > nameB) return  1 * direction;
      return 0;
    });

    // ── 6. Respond ────────────────────────────────────────────────────────────
    res.status(200).json({
      count: trips.length,
      results: trips,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  tripsList,
  tripReadOne,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip,
  tripsDeleteById,
  tripsSearch,
};
