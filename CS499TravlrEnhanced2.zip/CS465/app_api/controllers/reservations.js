/**
 * reservations.js
 * Express controller for the Reservations REST API.
 *
 * All write operations (create, update, cancel) require a valid JWT, which the
 * authenticate middleware attaches to req.auth before these handlers run.
 * The confirm endpoint additionally requires the isAdmin middleware.
 *
 * Endpoint summary:
 *   GET    /api/reservations                → reservationsList    (own reservations)
 *   POST   /api/reservations                → reservationsCreate  (create booking)
 *   GET    /api/reservations/:id            → reservationReadOne  (single booking)
 *   PUT    /api/reservations/:id            → reservationsUpdate  (modify booking)
 *   DELETE /api/reservations/:id            → reservationsCancel  (cancel booking)
 *   PUT    /api/reservations/:id/confirm    → reservationsConfirm (admin only)
 */
const mongoose = require('mongoose');

// Register the schema before calling mongoose.model() — the schema file
// is idempotent so requiring it multiple times is safe.
require('../models/reservation');
require('../models/travlr');

const Reservation = mongoose.model('reservations');
const Trip        = mongoose.model('trips');

/**
 * Fields a user is allowed to supply when creating or updating a reservation.
 * Prevents mass-assignment of userId, status, or internal fields.
 */
const ALLOWED_FIELDS = ['tripCode', 'guests', 'specialRequests'];

/**
 * Fields a user may update on an existing reservation.
 * Status changes are handled separately via the cancel endpoint.
 */
const UPDATE_FIELDS = ['guests', 'specialRequests'];

/**
 * Extracts only the allowed fields from a request body.
 *
 * @param {object}   body   - Raw req.body
 * @param {string[]} fields - Allow-list of field names
 * @returns {object} Sanitised subset of body
 */
const sanitise = (body, fields) =>
  fields.reduce((acc, f) => {
    if (body[f] !== undefined) acc[f] = body[f];
    return acc;
  }, {});

// ── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Returns true when `id` is a syntactically valid MongoDB ObjectId string.
 *
 * @param {string} id
 * @returns {boolean}
 */
const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

// ── Controller functions ──────────────────────────────────────────────────────

/**
 * GET /api/reservations
 * Returns all reservations belonging to the authenticated user,
 * sorted newest-first.
 *
 * @param {object} req       - Express request (req.auth populated by middleware)
 * @param {object} res       - Express response
 */
const reservationsList = async (req, res) => {
  try {
    const reservations = await Reservation
      .find({ userId: req.auth._id })
      .sort({ createdAt: -1 });
    res.status(200).json(reservations);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * POST /api/reservations
 * Creates a new reservation for the authenticated user.
 *
 * Validates that:
 *  - tripCode and guests are present
 *  - guests is a positive integer
 *  - the referenced trip exists in the database
 *
 * The tripName is denormalised from the Trip document so the reservation
 * remains readable even if the trip is later renamed.
 *
 * @param {object} req       - Express request
 * @param {object} req.body  - { tripCode, guests, specialRequests? }
 * @param {object} res       - Express response
 */
const reservationsCreate = async (req, res) => {
  const { tripCode, guests, specialRequests } = req.body;

  // ── Input validation ──────────────────────────────────────────────────────
  if (!tripCode || guests === undefined) {
    return res.status(400).json({ message: 'tripCode and guests are required' });
  }

  const guestCount = parseInt(guests, 10);
  if (isNaN(guestCount) || guestCount < 1) {
    return res.status(400).json({ message: 'guests must be a positive integer' });
  }

  try {
    // Verify the trip exists and grab its display name
    const trip = await Trip.findOne({ code: tripCode });
    if (!trip) {
      return res.status(404).json({ message: `Trip '${tripCode}' not found` });
    }

    // ── Duplicate booking prevention ──────────────────────────────────────
    // Block a second active booking for the same trip by the same user.
    // A 'cancelled' reservation does not count — the user may rebook after
    // cancelling. 'pending' and 'confirmed' reservations both block a new one.
    const existing = await Reservation.findOne({
      userId:   req.auth._id,
      tripCode: trip.code,
      status:   { $in: ['pending', 'confirmed'] }
    });
    if (existing) {
      return res.status(409).json({
        message: `You already have an active reservation for '${trip.name}'. Cancel it before booking again.`,
        existingReservationId: existing._id
      });
    }

    const reservation = new Reservation({
      userId:          req.auth._id,
      tripCode:        trip.code,
      tripName:        trip.name,
      guests:          guestCount,
      specialRequests: specialRequests || '',
      status:          'pending'
    });

    const saved = await reservation.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

/**
 * GET /api/reservations/:id
 * Returns a single reservation by its MongoDB _id.
 * Only the owner of the reservation may view it.
 *
 * @param {object} req              - Express request
 * @param {string} req.params.id    - Reservation MongoDB _id
 * @param {object} res              - Express response
 */
const reservationReadOne = async (req, res) => {
  if (!isValidObjectId(req.params.id)) {
    return res.status(400).json({ message: 'Invalid reservation ID' });
  }

  try {
    const reservation = await Reservation.findById(req.params.id);

    if (!reservation) {
      return res.status(404).json({ message: 'Reservation not found' });
    }

    // Ownership check — users may only view their own reservations
    if (reservation.userId.toString() !== req.auth._id.toString()) {
      return res.status(403).json({ message: 'Forbidden: not your reservation' });
    }

    res.status(200).json(reservation);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * PUT /api/reservations/:id
 * Updates the mutable fields (guests, specialRequests) of an existing reservation.
 *
 * Business rules:
 *  - Only the owner may update their reservation.
 *  - Cancelled reservations cannot be modified.
 *
 * @param {object} req              - Express request
 * @param {string} req.params.id    - Reservation MongoDB _id
 * @param {object} req.body         - Fields to update: { guests?, specialRequests? }
 * @param {object} res              - Express response
 */
const reservationsUpdate = async (req, res) => {
  if (!isValidObjectId(req.params.id)) {
    return res.status(400).json({ message: 'Invalid reservation ID' });
  }

  try {
    const reservation = await Reservation.findById(req.params.id);

    if (!reservation) {
      return res.status(404).json({ message: 'Reservation not found' });
    }

    if (reservation.userId.toString() !== req.auth._id.toString()) {
      return res.status(403).json({ message: 'Forbidden: not your reservation' });
    }

    if (reservation.status === 'cancelled') {
      return res.status(400).json({ message: 'Cannot modify a cancelled reservation' });
    }

    const updates = sanitise(req.body, UPDATE_FIELDS);

    if (updates.guests !== undefined) {
      const guestCount = parseInt(updates.guests, 10);
      if (isNaN(guestCount) || guestCount < 1) {
        return res.status(400).json({ message: 'guests must be a positive integer' });
      }
      updates.guests = guestCount;
    }

    const updated = await Reservation.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    );

    res.status(200).json(updated);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

/**
 * DELETE /api/reservations/:id
 * Cancels a reservation by setting its status to 'cancelled'.
 * The document is retained for history; it is never hard-deleted.
 *
 * Business rules:
 *  - Only the owner may cancel their reservation.
 *  - Already-cancelled reservations return 400.
 *
 * @param {object} req              - Express request
 * @param {string} req.params.id    - Reservation MongoDB _id
 * @param {object} res              - Express response
 */
const reservationsCancel = async (req, res) => {
  if (!isValidObjectId(req.params.id)) {
    return res.status(400).json({ message: 'Invalid reservation ID' });
  }

  try {
    const reservation = await Reservation.findById(req.params.id);

    if (!reservation) {
      return res.status(404).json({ message: 'Reservation not found' });
    }

    if (reservation.userId.toString() !== req.auth._id.toString()) {
      return res.status(403).json({ message: 'Forbidden: not your reservation' });
    }

    if (reservation.status === 'cancelled') {
      return res.status(400).json({ message: 'Reservation is already cancelled' });
    }

    reservation.status = 'cancelled';
    const cancelled = await reservation.save();
    res.status(200).json(cancelled);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * PUT /api/reservations/:id/confirm
 * Admin-only endpoint. Moves a reservation from 'pending' to 'confirmed'.
 *
 * Business rules:
 *  - Caller must have role === 'admin' (enforced by isAdmin middleware upstream).
 *  - Only 'pending' reservations can be confirmed.
 *  - Cancelled reservations cannot be confirmed.
 *
 * @param {object} req           - Express request
 * @param {string} req.params.id - Reservation MongoDB _id
 * @param {object} res           - Express response
 */
const reservationsConfirm = async (req, res) => {
  if (!isValidObjectId(req.params.id)) {
    return res.status(400).json({ message: 'Invalid reservation ID' });
  }

  try {
    const reservation = await Reservation.findById(req.params.id);

    if (!reservation) {
      return res.status(404).json({ message: 'Reservation not found' });
    }

    if (reservation.status === 'cancelled') {
      return res.status(400).json({ message: 'Cannot confirm a cancelled reservation' });
    }

    if (reservation.status === 'confirmed') {
      return res.status(400).json({ message: 'Reservation is already confirmed' });
    }

    reservation.status = 'confirmed';
    const confirmed = await reservation.save();
    res.status(200).json(confirmed);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  reservationsList,
  reservationsCreate,
  reservationReadOne,
  reservationsUpdate,
  reservationsCancel,
  reservationsConfirm
};
