const passport = require('passport');
const mongoose = require('mongoose');
const User = mongoose.model('users');
const jwt = require('jsonwebtoken');

// Fail fast if JWT_SECRET is not set — never run with a known public secret
if (!process.env.JWT_SECRET) {
  throw new Error('FATAL: JWT_SECRET environment variable is not set. Set it in your .env file before starting the server.');
}

/**
 * Generates a signed JWT for the given user, valid for 7 days.
 *
 * @param {object} user - Mongoose User document
 * @param {string} user._id   - MongoDB ObjectId
 * @param {string} user.email - User's email address
 * @param {string} user.name  - User's display name
 * @returns {string} Signed JWT string
 */
const generateJwt = (user) => {
  const expiry = new Date();
  expiry.setDate(expiry.getDate() + 7); // token valid for 7 days

  return jwt.sign(
    {
      _id:   user._id,
      email: user.email,
      name:  user.name,
      role:  user.role || 'user',   // include role so middleware can check it without a DB round-trip
      exp:   parseInt(expiry.getTime() / 1000, 10)
    },
    process.env.JWT_SECRET
  );
};

/**
 * POST /api/register
 * Registers a new user account. Validates required fields, checks for duplicate
 * email addresses, hashes the password, and returns a signed JWT on success.
 *
 * @param {object} req               - Express request object
 * @param {object} req.body          - Request body
 * @param {string} req.body.name     - User's display name
 * @param {string} req.body.email    - User's email address (must be unique)
 * @param {string} req.body.password - Plain-text password (hashed before storage)
 * @param {object} res               - Express response object
 */
const register = async (req, res) => {
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required: name, email, password' });
  }

  try {
    const existing = await User.findOne({ email: req.body.email.toLowerCase() });
    if (existing) {
      return res.status(409).json({ message: 'Email already registered' });
    }

    // Build the hash first, then pass all required fields into the constructor
    // so Mongoose validation sees a complete document from the start.
    const saltRounds = 10;
    const bcrypt = require('bcryptjs');
    const hash = bcrypt.hashSync(req.body.password, saltRounds);

    const user = new User({
      name: req.body.name,
      email: req.body.email.toLowerCase(),
      hash
    });

    await user.save();

    const token = generateJwt(user);
    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * POST /api/login
 * Authenticates an existing user. Validates credentials and returns a signed JWT
 * on success, or 401 if the email/password combination is incorrect.
 *
 * @param {object} req               - Express request object
 * @param {object} req.body          - Request body
 * @param {string} req.body.email    - User's registered email address
 * @param {string} req.body.password - Plain-text password to verify
 * @param {object} res               - Express response object
 */
const login = async (req, res) => {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required: email, password' });
  }

  try {
    const user = await User.findOne({ email: req.body.email.toLowerCase() });
    if (!user || !user.validPassword(req.body.password)) {
      return res.status(401).json({ message: 'Incorrect email or password' });
    }

    const token = generateJwt(user);
    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { register, login };
