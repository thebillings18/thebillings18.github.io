/**
 * isAdmin.js
 * Express middleware that enforces admin-only access on protected routes.
 *
 * Must be used AFTER the `authenticate` middleware, which decodes the JWT
 * and attaches the payload to req.auth. This middleware then checks that
 * req.auth.role === 'admin' before allowing the request to proceed.
 *
 * Usage in routes:
 *   router.put('/reservations/:id/confirm', authenticate, isAdmin, handler);
 *
 * Error responses:
 *   401 — No token / invalid token (handled upstream by authenticate)
 *   403 — Valid token but role is not 'admin'
 *
 * @param {object}   req  - Express request object (req.auth set by authenticate)
 * @param {object}   res  - Express response object
 * @param {Function} next - Express next middleware function
 */
const isAdmin = (req, res, next) => {
  if (!req.auth || req.auth.role !== 'admin') {
    return res.status(403).json({
      message: 'Forbidden: admin access required'
    });
  }
  next();
};

module.exports = { isAdmin };
