const jwt = require('jsonwebtoken');

/**
 * Express middleware that enforces JWT authentication on protected routes.
 * Expects an "Authorization: Bearer <token>" header.
 * On success, attaches the decoded payload to req.auth and calls next().
 * On failure, responds with 401 Unauthorized.
 *
 * @param {object}   req  - Express request object
 * @param {object}   res  - Express response object
 * @param {Function} next - Express next middleware function
 */
const authenticate = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Unauthorized: No token provided' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.auth = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Unauthorized: Invalid or expired token' });
  }
};

module.exports = { authenticate };
