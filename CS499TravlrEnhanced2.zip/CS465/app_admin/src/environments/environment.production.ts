/**
 * environment.production.ts
 * Production environment configuration for the Travlr Getaways Angular admin SPA.
 * Swapped in automatically by the Angular CLI during `ng build --configuration production`.
 * Update apiBaseUrl to your deployed API server URL before building for production.
 */
export const environment = {
  production: true,
  apiBaseUrl: 'https://your-production-api.example.com/api'
};
