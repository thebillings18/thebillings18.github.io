/**
 * environment.ts
 * Development environment configuration for the Travlr Getaways Angular admin SPA.
 * This file is replaced by environment.production.ts during a production build
 * via the Angular build configuration in angular.json.
 */
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3000/api'
};
