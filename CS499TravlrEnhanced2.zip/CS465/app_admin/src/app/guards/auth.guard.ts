/**
 * auth.guard.ts
 * Route guard that protects admin-only routes in the Travlr Getaways SPA.
 *
 * Applied to the add-trip and edit-trip routes in app.routes.ts.
 * The trip listing (/) is intentionally left unguarded so unauthenticated
 * users can browse trips — only mutation operations require a valid session.
 *
 * isLoggedIn() checks both the presence of a JWT in localStorage and that
 * its 'exp' claim has not passed, so an expired token is treated the same
 * as no token (see AuthenticationService.isLoggedIn).
 */
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

/**
 * Functional route guard — returns true if the user holds a valid, non-expired
 * JWT; otherwise redirects to /login and returns false to cancel navigation.
 */
export const authGuard: CanActivateFn = () => {
  const authService = inject(AuthenticationService);
  const router = inject(Router);

  if (authService.isLoggedIn()) {
    return true;
  }

  // Redirect unauthenticated users to the login page.
  // The original destination is not preserved because the SPA has only two
  // protected routes and both return to the listing on success anyway.
  router.navigate(['/login']);
  return false;
};
