import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.component.html',
  styleUrls: ['./trip-card.component.css']
})
export class TripCardComponent implements OnInit {
  @Input() trip!: Trip;
  /** Passed from the parent listing — controls visibility of Edit and Delete buttons. */
  @Input() isLoggedIn: boolean = false;
  @Output() deleteRequested = new EventEmitter<string>();

  constructor(private router: Router) {}

  ngOnInit(): void {}

  editTrip(trip: Trip): void {
    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['/edit-trip']);
  }

  onDeleteTrip(): void {
    this.deleteRequested.emit(this.trip.code);
  }
}
