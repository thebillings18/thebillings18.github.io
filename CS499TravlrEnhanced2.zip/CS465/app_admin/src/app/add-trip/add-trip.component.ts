/**
 * add-trip.component.ts
 * Protected admin component for creating a new trip record.
 *
 * Access is restricted by authGuard (see app.routes.ts) — unauthenticated
 * users are redirected to /login before this component ever loads.
 *
 * On successful submission the API returns the saved document and the user
 * is navigated back to the trip listing. Validation errors are surfaced in
 * the template via the `f` accessor and the `submitted` flag.
 */
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { TripDataService } from '../services/trip-data.service';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-trip.component.html',
  styleUrls: ['./add-trip.component.css']
})
export class AddTripComponent implements OnInit {
  public addForm!: FormGroup;

  /** Tracks whether the form has been submitted; enables validation error display in the template. */
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripService: TripDataService
  ) { }

  ngOnInit() {
    /**
     * Form group mirrors the Trip model schema.
     * 'code' and 'name' are required — code is the lookup key used by
     * edit and delete operations; name is required by the Mongoose schema.
     * All other fields are optional to allow partial trip records.
     */
    this.addForm = this.formBuilder.group({
      _id:         [],
      code:        ["", Validators.required],
      name:        ["", Validators.required],
      length:      [""],
      start:       [""],
      resort:      [""],
      perPerson:   [""],
      image:       [""],
      description: [""]
    });
  }

  /**
   * Handles form submission. Sets the submitted flag so the template can
   * display validation feedback, then calls the API only if the form is valid.
   * Navigates to the trip listing on success.
   */
  public onSubmit() {
    this.submitted = true;
    if (this.addForm.valid) {
      this.tripService.addTrip(this.addForm.value)
        .subscribe({
          next: (data: any) => {
            console.log(data);
            this.router.navigate(['']);
          },
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }

  /**
   * Convenience accessor for template-side validation.
   * Allows the template to reference controls as `f.code.errors` rather than
   * the more verbose `addForm.controls.code.errors`.
   */
  get f() {
    return this.addForm.controls;
  }
}
