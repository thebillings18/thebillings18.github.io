/**
 * login.component.ts
 * Public authentication component for the Travlr Getaways admin SPA.
 *
 * Submits credentials to POST /api/login via AuthenticationService.
 * On success, the service stores the returned JWT in localStorage and
 * this component navigates to the trip listing (/), where admin controls
 * become visible because isLoggedIn() now returns true.
 *
 * On failure, the API error message is surfaced directly in the template
 * so the user receives specific feedback (e.g. "Incorrect email or password")
 * rather than a generic error string.
 */
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  credentials = { email: '', password: '' };

  /** Bound to the template error display; populated on validation failure or API error. */
  errorMessage = '';

  constructor(
    private authService: AuthenticationService,
    private router: Router
  ) {}

  /**
   * Handles login form submission.
   * Performs client-side presence validation before calling the API to avoid
   * an unnecessary network round-trip for obviously empty fields.
   * The API error message is preferred over a generic fallback so the user
   * gets actionable feedback.
   */
  onSubmit(): void {
    this.errorMessage = '';
    const { email, password } = this.credentials;

    if (!email || !password) {
      this.errorMessage = 'Email and password are required.';
      return;
    }

    this.authService.login(email, password).subscribe({
      next: () => this.router.navigate(['/']),
      error: (err) => {
        // Prefer the server's error message; fall back if the response has no body
        this.errorMessage = err.error?.message || 'Login failed. Please try again.';
      }
    });
  }
}
