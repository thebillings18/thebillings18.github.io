/**
 * add-reservation.component.ts
 * Form component for creating a new reservation.
 *
 * Workflow:
 *  1. Loads the full trip list so the user can pick a trip from a dropdown.
 *  2. On submit, calls ReservationDataService.createReservation().
 *  3. On success, navigates to the reservation listing page.
 */
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ReservationDataService } from '../services/reservation-data.service';
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';
import { CreateReservationPayload } from '../models/reservation';

@Component({
  selector: 'app-add-reservation',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './add-reservation.component.html'
})
export class AddReservationComponent implements OnInit {

  trips: Trip[] = [];
  message = '';
  submitted = false;

  /** Form model — bound via ngModel in the template */
  formData: CreateReservationPayload = {
    tripCode:        '',
    guests:          1,
    specialRequests: ''
  };

  constructor(
    private reservationService: ReservationDataService,
    private tripService: TripDataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.tripService.getTrips().subscribe({
      next:  (trips) => { this.trips = trips; },
      error: (err)   => { this.message = `Could not load trips: ${err.error?.message || err.message}`; }
    });
  }

  /**
   * Submits the form to create a new reservation.
   * Guards against double-submission via the `submitted` flag.
   */
  onSubmit(): void {
    if (this.submitted) return;

    if (!this.formData.tripCode) {
      this.message = 'Please select a trip.';
      return;
    }
    if (!this.formData.guests || this.formData.guests < 1) {
      this.message = 'Number of guests must be at least 1.';
      return;
    }

    this.submitted = true;
    this.message   = '';

    this.reservationService.createReservation(this.formData).subscribe({
      next: () => {
        this.router.navigate(['/reservations']);
      },
      error: (err) => {
        this.message   = `Error creating reservation: ${err.error?.message || err.message}`;
        this.submitted = false;
      }
    });
  }
}
