/**
 * edit-reservation.component.ts
 * Form component for modifying an existing reservation.
 *
 * Workflow:
 *  1. Reads the reservation _id from localStorage (set by ReservationListingComponent).
 *  2. Fetches the current reservation data and pre-populates the form.
 *  3. On submit, calls ReservationDataService.updateReservation().
 *  4. On success, navigates back to the reservation listing page.
 */
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ReservationDataService } from '../services/reservation-data.service';
import { Reservation, UpdateReservationPayload } from '../models/reservation';

@Component({
  selector: 'app-edit-reservation',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './edit-reservation.component.html'
})
export class EditReservationComponent implements OnInit {

  reservation: Reservation | null = null;
  message   = '';
  submitted = false;
  loading   = true;

  /** Form model — bound via ngModel in the template */
  formData: UpdateReservationPayload = {
    guests:          1,
    specialRequests: ''
  };

  constructor(
    private reservationService: ReservationDataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = localStorage.getItem('reservationId');
    if (!id) {
      this.message = 'No reservation selected. Please go back and choose a reservation to edit.';
      this.loading = false;
      return;
    }

    this.reservationService.getReservation(id).subscribe({
      next: (res) => {
        this.reservation       = res;
        this.formData.guests          = res.guests;
        this.formData.specialRequests = res.specialRequests;
        this.loading = false;
      },
      error: (err) => {
        this.message = `Error loading reservation: ${err.error?.message || err.message}`;
        this.loading = false;
      }
    });
  }

  /**
   * Submits the updated fields to the API.
   * Guards against double-submission via the `submitted` flag.
   */
  onSubmit(): void {
    if (this.submitted || !this.reservation) return;

    if (!this.formData.guests || this.formData.guests < 1) {
      this.message = 'Number of guests must be at least 1.';
      return;
    }

    this.submitted = true;
    this.message   = '';

    this.reservationService.updateReservation(this.reservation._id, this.formData).subscribe({
      next: () => {
        localStorage.removeItem('reservationId');
        this.router.navigate(['/reservations']);
      },
      error: (err) => {
        this.message   = `Error updating reservation: ${err.error?.message || err.message}`;
        this.submitted = false;
      }
    });
  }
}
