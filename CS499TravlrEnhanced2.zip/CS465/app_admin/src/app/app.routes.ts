import { Routes } from '@angular/router';
import { AddTripComponent } from './add-trip/add-trip.component';
import { TripListingComponent } from './trip-listing/trip-listing.component';
import { EditTripComponent } from './edit-trip/edit-trip.component';
import { LoginComponent } from './login/login.component';
import { authGuard } from './guards/auth.guard';
import { ReservationListingComponent } from './reservation-listing/reservation-listing.component';
import { AddReservationComponent } from './add-reservation/add-reservation.component';
import { EditReservationComponent } from './edit-reservation/edit-reservation.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  // Trip listing is public — anyone can browse trips without logging in
  { path: '', component: TripListingComponent, pathMatch: 'full' },
  // Add and Edit require authentication — protected by authGuard
  { path: 'add-trip',  component: AddTripComponent,  canActivate: [authGuard] },
  { path: 'edit-trip', component: EditTripComponent, canActivate: [authGuard] },
  // Reservation routes — all protected by authGuard
  { path: 'reservations',     component: ReservationListingComponent, canActivate: [authGuard] },
  { path: 'add-reservation',  component: AddReservationComponent,     canActivate: [authGuard] },
  { path: 'edit-reservation', component: EditReservationComponent,    canActivate: [authGuard] },
];
