/**
 * reservation.ts
 * TypeScript interfaces for the Reservation domain object.
 *
 * Mirrors the Mongoose schema defined in app_api/models/reservation.js.
 * Used throughout the Angular SPA for type-safe HTTP responses and form data.
 */

/**
 * Represents the status lifecycle of a reservation.
 *  pending   → newly created, awaiting confirmation
 *  confirmed → booking has been confirmed
 *  cancelled → booking was cancelled by the user
 */
export type ReservationStatus = 'pending' | 'confirmed' | 'cancelled';

/**
 * Full reservation document as returned by the API.
 * All fields are present on a document retrieved from the server.
 */
export interface Reservation {
  /** MongoDB ObjectId string */
  _id: string;

  /** ObjectId of the user who made the booking */
  userId: string;

  /** Trip code linking this reservation to a Trip document */
  tripCode: string;

  /** Denormalised trip display name (snapshot at booking time) */
  tripName: string;

  /** Number of guests included in the booking (≥ 1) */
  guests: number;

  /** Optional free-text field for dietary needs, accessibility, etc. */
  specialRequests: string;

  /** Current workflow state of the reservation */
  status: ReservationStatus;

  /** ISO 8601 timestamp — set automatically by Mongoose */
  createdAt: string;

  /** ISO 8601 timestamp — updated automatically by Mongoose on save */
  updatedAt: string;
}

/**
 * Payload sent to POST /api/reservations to create a new booking.
 * userId and status are assigned server-side; only these three fields
 * are accepted from the client.
 */
export interface CreateReservationPayload {
  tripCode: string;
  guests: number;
  specialRequests?: string;
}

/**
 * Payload sent to PUT /api/reservations/:id to modify an existing booking.
 * Only mutable fields are included; tripCode and status cannot be changed
 * through this payload.
 */
export interface UpdateReservationPayload {
  guests?: number;
  specialRequests?: string;
}
