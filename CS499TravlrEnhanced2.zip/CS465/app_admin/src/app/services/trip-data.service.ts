import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { AuthenticationService } from './authentication.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  /** Base URL for the trips API endpoint, sourced from the environment config. */
  url = `${environment.apiBaseUrl}/trips`;

  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) {}

  /**
   * Builds an HttpOptions object containing the Authorization and Content-Type headers
   * required for protected API calls. Reads the JWT from AuthenticationService.
   *
   * @returns {{ headers: HttpHeaders }} Options object ready to pass to HttpClient methods
   */
  private authHeaders(): { headers: HttpHeaders } {
    const token = this.authService.getToken();
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      })
    };
  }

  /**
   * Fetches all trips from the API. No authentication required.
   *
   * @returns {Observable<Trip[]>} Observable that emits an array of Trip objects
   */
  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url);
  }

  /**
   * Fetches a single trip by its unique trip code. No authentication required.
   *
   * @param {string} tripCode - The unique code identifying the trip
   * @returns {Observable<Trip>} Observable that emits the matching Trip object
   */
  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.url}/${tripCode}`);
  }

  /**
   * Creates a new trip. Requires a valid JWT (protected endpoint).
   *
   * @param {Trip} formData - The trip data to submit
   * @returns {Observable<Trip>} Observable that emits the newly created Trip
   */
  addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.url, formData, this.authHeaders());
  }

  /**
   * Updates an existing trip identified by its trip code. Requires a valid JWT.
   *
   * @param {string} tripCode - The unique code of the trip to update
   * @param {Trip}   formData - The updated trip data
   * @returns {Observable<Trip>} Observable that emits the updated Trip
   */
  updateTrip(tripCode: string, formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.url}/${tripCode}`, formData, this.authHeaders());
  }

  /**
   * Deletes a trip identified by its trip code. Requires a valid JWT.
   *
   * @param {string} tripCode - The unique code of the trip to delete
   * @returns {Observable<void>} Observable that completes when the trip is deleted
   */
  deleteTrip(tripCode: string): Observable<void> {
    return this.http.delete<void>(`${this.url}/${tripCode}`, this.authHeaders());
  }

  /**
   * Searches, filters, and sorts trips via GET /api/trips/search.
   * All parameters are optional — omitting all returns every trip sorted by name.
   *
   * @param params.q          Keyword matched against name, resort, description, and code
   * @param params.minDays    Minimum trip length in days (inclusive)
   * @param params.maxDays    Maximum trip length in days (inclusive)
   * @param params.minPrice   Minimum per-person price (inclusive)
   * @param params.maxPrice   Maximum per-person price (inclusive)
   * @param params.sortBy     Sort field: 'name' | 'length' | 'price'  (default: 'name')
   * @param params.sortOrder  Sort direction: 'asc' | 'desc'           (default: 'asc')
   * @returns Observable emitting { count: number; results: Trip[] }
   */
  searchTrips(params: {
    q?:         string;
    minDays?:   number;
    maxDays?:   number;
    minPrice?:  number;
    maxPrice?:  number;
    sortBy?:    'name' | 'length' | 'price';
    sortOrder?: 'asc' | 'desc';
  }): Observable<{ count: number; results: Trip[] }> {
    let httpParams = new HttpParams();
    if (params.q         != null && params.q !== '')   httpParams = httpParams.set('q',         params.q);
    if (params.minDays   != null)                      httpParams = httpParams.set('minDays',   String(params.minDays));
    if (params.maxDays   != null)                      httpParams = httpParams.set('maxDays',   String(params.maxDays));
    if (params.minPrice  != null)                      httpParams = httpParams.set('minPrice',  String(params.minPrice));
    if (params.maxPrice  != null)                      httpParams = httpParams.set('maxPrice',  String(params.maxPrice));
    if (params.sortBy    != null)                      httpParams = httpParams.set('sortBy',    params.sortBy);
    if (params.sortOrder != null)                      httpParams = httpParams.set('sortOrder', params.sortOrder);
    return this.http.get<{ count: number; results: Trip[] }>(`${this.url}/search`, { params: httpParams });
  }
}
