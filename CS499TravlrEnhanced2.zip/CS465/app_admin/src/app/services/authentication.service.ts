import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { AuthResponse } from '../models/user';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  /** Base URL for the authentication API endpoints, sourced from the environment config. */
  private baseUrl = environment.apiBaseUrl;

  /** localStorage key used to persist the JWT between sessions. */
  private tokenKey = 'travlr-token';

  constructor(private http: HttpClient) {}

  /**
   * Sends a registration request to the API and stores the returned JWT.
   *
   * @param {string} name     - The new user's display name
   * @param {string} email    - The new user's email address
   * @param {string} password - The new user's plain-text password
   * @returns {Observable<AuthResponse>} Observable that emits the auth response containing the JWT
   */
  register(name: string, email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.baseUrl}/register`, { name, email, password })
      .pipe(tap(res => this.saveToken(res.token)));
  }

  /**
   * Sends a login request to the API and stores the returned JWT on success.
   *
   * @param {string} email    - The user's registered email address
   * @param {string} password - The user's plain-text password
   * @returns {Observable<AuthResponse>} Observable that emits the auth response containing the JWT
   */
  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.baseUrl}/login`, { email, password })
      .pipe(tap(res => this.saveToken(res.token)));
  }

  /**
   * Logs the current user out by removing the stored JWT from localStorage.
   */
  logout(): void {
    localStorage.removeItem(this.tokenKey);
  }

  /**
   * Persists the JWT to localStorage under the configured token key.
   *
   * @param {string} token - The signed JWT string to store
   */
  private saveToken(token: string): void {
    localStorage.setItem(this.tokenKey, token);
  }

  /**
   * Retrieves the stored JWT from localStorage.
   *
   * @returns {string | null} The JWT string, or null if no token is stored
   */
  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  /**
   * Checks whether the current user is logged in by verifying that a non-expired
   * JWT is present in localStorage.
   *
   * @returns {boolean} True if a valid, non-expired token exists; false otherwise
   */
  isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) return false;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Math.floor(Date.now() / 1000);
    } catch {
      return false;
    }
  }

  /**
   * Decodes the stored JWT payload to retrieve the current user's name, email and role.
   * Returns null if no token is present or if the token cannot be decoded.
   *
   * @returns {{ name: string; email: string; role: string } | null} Decoded user info, or null
   */
  getCurrentUser(): { name: string; email: string; role: string } | null {
    const token = this.getToken();
    if (!token) return null;
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch {
      return null;
    }
  }

  /**
   * Returns true when the currently logged-in user has the 'admin' role.
   * Reads the role directly from the decoded JWT — no extra API call needed.
   *
   * @returns {boolean} True if the user is an admin; false otherwise
   */
  isAdmin(): boolean {
    return this.getCurrentUser()?.role === 'admin';
  }
}
