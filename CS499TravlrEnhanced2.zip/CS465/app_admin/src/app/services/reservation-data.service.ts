/**
 * reservation-data.service.ts
 * Angular service for all Reservation API interactions.
 *
 * Wraps the five reservation endpoints exposed by the Express API:
 *   GET    /api/reservations            → getReservations()
 *   POST   /api/reservations            → createReservation()
 *   GET    /api/reservations/:id        → getReservation()
 *   PUT    /api/reservations/:id        → updateReservation()
 *   DELETE /api/reservations/:id        → cancelReservation()
 *
 * All requests attach a Bearer JWT via authHeaders(), mirroring the
 * pattern used in TripDataService.
 */
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  Reservation,
  CreateReservationPayload,
  UpdateReservationPayload
} from '../models/reservation';
import { AuthenticationService } from './authentication.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReservationDataService {

  /** Base URL for the reservations API endpoint. */
  private url = `${environment.apiBaseUrl}/reservations`;

  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) {}

  /**
   * Builds an HttpOptions object with Authorization and Content-Type headers.
   * Reads the current JWT from AuthenticationService.
   *
   * @returns {{ headers: HttpHeaders }} Options object for HttpClient methods
   */
  private authHeaders(): { headers: HttpHeaders } {
    const token = this.authService.getToken();
    return {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${token}`
      })
    };
  }

  /**
   * GET /api/reservations
   * Fetches all reservations belonging to the authenticated user,
   * sorted newest-first by the API.
   *
   * @returns {Observable<Reservation[]>} Observable emitting the user's reservations
   */
  getReservations(): Observable<Reservation[]> {
    return this.http.get<Reservation[]>(this.url, this.authHeaders());
  }

  /**
   * GET /api/reservations/:id
   * Fetches a single reservation by its MongoDB _id.
   *
   * @param {string} id - The reservation's MongoDB ObjectId string
   * @returns {Observable<Reservation>} Observable emitting the matching reservation
   */
  getReservation(id: string): Observable<Reservation> {
    return this.http.get<Reservation>(`${this.url}/${id}`, this.authHeaders());
  }

  /**
   * POST /api/reservations
   * Creates a new reservation for the authenticated user.
   *
   * @param {CreateReservationPayload} payload - { tripCode, guests, specialRequests? }
   * @returns {Observable<Reservation>} Observable emitting the newly created reservation
   */
  createReservation(payload: CreateReservationPayload): Observable<Reservation> {
    return this.http.post<Reservation>(this.url, payload, this.authHeaders());
  }

  /**
   * PUT /api/reservations/:id
   * Updates the mutable fields of an existing reservation.
   *
   * @param {string}                    id      - The reservation's MongoDB ObjectId string
   * @param {UpdateReservationPayload}  payload - Fields to update: { guests?, specialRequests? }
   * @returns {Observable<Reservation>} Observable emitting the updated reservation
   */
  updateReservation(id: string, payload: UpdateReservationPayload): Observable<Reservation> {
    return this.http.put<Reservation>(`${this.url}/${id}`, payload, this.authHeaders());
  }

  /**
   * DELETE /api/reservations/:id
   * Cancels a reservation (sets status to 'cancelled'; document is retained).
   *
   * @param {string} id - The reservation's MongoDB ObjectId string
   * @returns {Observable<Reservation>} Observable emitting the cancelled reservation document
   */
  cancelReservation(id: string): Observable<Reservation> {
    return this.http.delete<Reservation>(`${this.url}/${id}`, this.authHeaders());
  }

  /**
   * PUT /api/reservations/:id/confirm
   * Admin-only. Moves a reservation from 'pending' to 'confirmed'.
   *
   * @param {string} id - The reservation's MongoDB ObjectId string
   * @returns {Observable<Reservation>} Observable emitting the confirmed reservation document
   */
  confirmReservation(id: string): Observable<Reservation> {
    return this.http.put<Reservation>(`${this.url}/${id}/confirm`, {}, this.authHeaders());
  }
}
