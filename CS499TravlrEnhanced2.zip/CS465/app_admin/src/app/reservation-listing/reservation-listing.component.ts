/**
 * reservation-listing.component.ts
 * Displays the authenticated user's full reservation history.
 *
 * Features:
 *  - Loads all reservations on init via ReservationDataService
 *  - Shows status badge (pending / confirmed / cancelled)
 *  - Allows the user to cancel any non-cancelled reservation
 *  - Links to the edit view for pending/confirmed reservations
 */
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { Reservation } from '../models/reservation';
import { ReservationDataService } from '../services/reservation-data.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-reservation-listing',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './reservation-listing.component.html'
})
export class ReservationListingComponent implements OnInit {

  reservations: Reservation[] = [];
  message = '';
  loading  = true;

  constructor(
    private reservationService: ReservationDataService,
    public  authService: AuthenticationService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadReservations();
  }

  /** Fetches the current user's reservations from the API. */
  loadReservations(): void {
    this.loading = true;
    this.reservationService.getReservations().subscribe({
      next: (data) => {
        this.reservations = data;
        this.loading = false;
      },
      error: (err) => {
        this.message = `Error loading reservations: ${err.error?.message || err.message}`;
        this.loading = false;
      }
    });
  }

  /**
   * Navigates to the edit-reservation view, passing the reservation _id
   * via router state so the edit component can pre-populate the form.
   *
   * @param reservation - The reservation to edit
   */
  editReservation(reservation: Reservation): void {
    localStorage.setItem('reservationId', reservation._id);
    this.router.navigate(['edit-reservation']);
  }

  /**
   * Cancels a reservation after the user confirms the action.
   *
   * @param id - MongoDB _id of the reservation to cancel
   */
  cancelReservation(id: string): void {
    if (!confirm('Are you sure you want to cancel this reservation?')) return;

    this.reservationService.cancelReservation(id).subscribe({
      next: () => {
        this.message = 'Reservation cancelled successfully.';
        this.loadReservations();
      },
      error: (err) => {
        this.message = `Error cancelling reservation: ${err.error?.message || err.message}`;
      }
    });
  }

  /**
   * Confirms a pending reservation (admin only).
   *
   * @param id - MongoDB _id of the reservation to confirm
   */
  confirmReservation(id: string): void {
    this.reservationService.confirmReservation(id).subscribe({
      next: () => {
        this.message = 'Reservation confirmed successfully.';
        this.loadReservations();
      },
      error: (err) => {
        this.message = `Error confirming reservation: ${err.error?.message || err.message}`;
      }
    });
  }

  /**
   * Returns a Bootstrap badge CSS class based on the reservation status.
   *
   * @param status - The reservation status string
   * @returns CSS class string for the badge
   */
  badgeClass(status: string): string {
    switch (status) {
      case 'confirmed':  return 'badge bg-success';
      case 'cancelled':  return 'badge bg-danger';
      default:           return 'badge bg-warning text-dark';
    }
  }
}
