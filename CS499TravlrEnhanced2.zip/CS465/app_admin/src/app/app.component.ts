/**
 * app.component.ts
 * Root component for the Travlr Getaways admin SPA.
 *
 * Hosts the router outlet and the top-level navigation bar.
 * AuthenticationService is injected as public so the template can call
 * authService.isLoggedIn() directly to show/hide the Login and Logout links
 * without requiring a separate component property.
 */
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router';
import { AuthenticationService } from './services/authentication.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Travlr Getaways Admin!';

  /**
   * authService is public so the template can call isLoggedIn() and
   * getCurrentUser() directly for conditional rendering of nav links.
   */
  constructor(
    public authService: AuthenticationService,
    private router: Router
  ) {}

  /**
   * Clears the stored JWT and redirects to the login page.
   * Called from the Logout button in the navigation bar.
   */
  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
