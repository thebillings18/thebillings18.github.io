/**
 * edit-trip.component.ts
 * Protected admin component for editing an existing trip record.
 *
 * Access is restricted by authGuard (see app.routes.ts).
 *
 * The trip to edit is identified by a trip code stored in localStorage under
 * the key 'tripCode'. This value is written by TripCardComponent when the user
 * clicks "Edit Trip", and read here in ngOnInit. Using localStorage allows the
 * code to survive the Angular router navigation without requiring route params
 * or a shared state service.
 *
 * Workflow:
 *  1. ngOnInit reads tripCode from localStorage and redirects home if missing.
 *  2. The form is built with tripCode pre-populated in the code control.
 *  3. The existing trip is fetched from the API and patched into the form.
 *  4. On submit, the updated form value is sent to PUT /api/trips/:tripCode.
 */
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.component.html',
  styleUrls: ['./edit-trip.component.css']
})
export class EditTripComponent implements OnInit {

  public editForm!: FormGroup;
  trip!: Trip;

  /** Tracks whether the form has been submitted; enables validation error display in the template. */
  submitted = false;

  /** Displayed in the template when the API fetch fails. */
  message: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripDataService
  ) {}

  ngOnInit(): void {
    const tripCode = localStorage.getItem('tripCode');

    // Guard: if no trip code is present the user navigated here directly
    // without selecting a trip — redirect rather than showing a broken form.
    if (!tripCode) {
      alert("Something went wrong, tripCode is missing!");
      this.router.navigate(['']);
      return;
    }

    // All fields are required on edit — a fully populated form ensures the PUT
    // request sends a complete document and does not accidentally null out fields.
    this.editForm = this.formBuilder.group({
      _id:         [],
      code:        [tripCode, Validators.required],
      name:        ["", Validators.required],
      length:      ["", Validators.required],
      start:       ["", Validators.required],
      resort:      ["", Validators.required],
      perPerson:   ["", Validators.required],
      image:       ["", Validators.required],
      description: ["", Validators.required]
    });

    // Fetch the current trip data and patch it into the form so the user
    // sees existing values rather than starting from blank fields.
    this.tripDataService.getTrip(tripCode).subscribe({
      next: (trip: Trip) => {
        this.trip = trip;
        this.editForm.patchValue(trip);
      },
      error: (error: any) => {
        console.error('Error fetching trip:', error);
        this.message = 'Error fetching trip data.';
      }
    });
  }

  /**
   * Handles form submission. Reads the trip code from the form value (not
   * localStorage) so the submitted code is always in sync with the form state.
   * Navigates to the trip listing on success.
   */
  public onSubmit(): void {
    this.submitted = true;

    if (this.editForm.valid) {
      const tripCode = this.editForm.value.code;

      this.tripDataService.updateTrip(tripCode, this.editForm.value).subscribe({
        next: (response: any) => {
          console.log('Trip updated:', response);
          this.router.navigate(['']);
        },
        error: (error: any) => {
          console.error('Error updating trip:', error);
        }
      });
    }
  }

  /**
   * Convenience accessor for template-side validation.
   * Allows the template to reference controls as `f.name.errors` rather than
   * the more verbose `editForm.controls.name.errors`.
   */
  get f() {
    return this.editForm.controls;
  }
}

