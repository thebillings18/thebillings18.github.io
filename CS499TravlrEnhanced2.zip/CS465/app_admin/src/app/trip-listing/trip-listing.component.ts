import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { TripCardComponent } from '../trip-card/trip-card.component';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, FormsModule, TripCardComponent],
  templateUrl: './trip-listing.component.html',
  styleUrls: ['./trip-listing.component.css'],
  providers: [TripDataService],
})
export class TripListingComponent implements OnInit {
  trips: Trip[] = [];
  message: string = '';

  /** True when a valid JWT is present — used to show/hide admin controls in the template. */
  isLoggedIn: boolean = false;

  // ── Search / filter / sort state ──────────────────────────────────────────
  /** Free-text keyword applied across name, resort, description, and code. */
  searchQuery: string = '';

  /** Minimum trip length in days. Empty string means no lower bound. */
  minDays: string = '';

  /** Maximum trip length in days. Empty string means no upper bound. */
  maxDays: string = '';

  /** Minimum per-person price. Empty string means no lower bound. */
  minPrice: string = '';

  /** Maximum per-person price. Empty string means no upper bound. */
  maxPrice: string = '';

  /** Field to sort results by. */
  sortBy: 'name' | 'length' | 'price' = 'name';

  /** Sort direction. */
  sortOrder: 'asc' | 'desc' = 'asc';

  /** True while a search request is in-flight. */
  isSearching: boolean = false;

  /** True once the user has run at least one search (controls result count display). */
  hasSearched: boolean = false;

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authService: AuthenticationService
  ) {
    console.log('trip-listing constructor');
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  public onDelete(tripCode: string): void {
    if (!tripCode) {
      console.error('Delete failed: trip has no code. Re-add the trip with a code value.');
      return;
    }
    this.tripDataService.deleteTrip(tripCode).subscribe({
      next: () => {
        console.log(`Trip with code ${tripCode} deleted successfully.`);
        this.hasSearched ? this.onSearch() : this.getStuff();
      },
      error: (error: any) => {
        console.error(`Error deleting trip ${tripCode}:`, error);
      }
    });
  }

  /**
   * Submits the current search/filter/sort criteria to GET /api/trips/search
   * and replaces the displayed trip list with the results.
   */
  public onSearch(): void {
    this.isSearching = true;
    this.hasSearched = true;

    this.tripDataService.searchTrips({
      q:         this.searchQuery  || undefined,
      minDays:   this.minDays  !== '' ? Number(this.minDays)  : undefined,
      maxDays:   this.maxDays  !== '' ? Number(this.maxDays)  : undefined,
      minPrice:  this.minPrice !== '' ? Number(this.minPrice) : undefined,
      maxPrice:  this.maxPrice !== '' ? Number(this.maxPrice) : undefined,
      sortBy:    this.sortBy,
      sortOrder: this.sortOrder,
    }).subscribe({
      next: (response) => {
        this.trips = response.results;
        this.message = response.count > 0
          ? `${response.count} trip${response.count === 1 ? '' : 's'} found.`
          : 'No trips matched your search criteria.';
        this.isSearching = false;
      },
      error: (error: any) => {
        console.error('Search error:', error);
        this.message = 'An error occurred while searching. Please try again.';
        this.isSearching = false;
      },
    });
  }

  /**
   * Resets all search/filter/sort fields and reloads the full trip list.
   */
  public onReset(): void {
    this.searchQuery = '';
    this.minDays     = '';
    this.maxDays     = '';
    this.minPrice    = '';
    this.maxPrice    = '';
    this.sortBy      = 'name';
    this.sortOrder   = 'asc';
    this.hasSearched = false;
    this.getStuff();
  }

  private getStuff(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        this.trips = value;
        this.message = value.length > 0
          ? `There are ${value.length} trips available.`
          : 'There were no trips retrieved from the database.';
        console.log(this.message);
      },
      error: (error: any) => {
        console.log('Error: ' + error);
      },
    });
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.isLoggedIn = this.authService.isLoggedIn();
    this.getStuff();
  }
}
