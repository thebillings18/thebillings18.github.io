/**
 * app_server/routes/news.js
 * Route definitions for the News page.
 * Mounted at '/news' in app.js.
 */
const express = require('express');
const router = express.Router();
const ctrlNews = require('../controllers/news');

router.get('/', ctrlNews.news);

module.exports = router;
