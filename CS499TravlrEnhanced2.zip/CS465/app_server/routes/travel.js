/**
 * app_server/routes/travel.js
 * Route definitions for the customer-facing travel packages page.
 * Mounted at '/travel' in app.js.
 *
 * The travel controller fetches live trip data from the internal REST API,
 * so this route indirectly depends on the API and MongoDB being available.
 */
const express = require('express');
const router = express.Router();
const travelController = require('../controllers/travel');

router.get('/', travelController.travel);

module.exports = router;
