/**
 * app_server/routes/rooms.js
 * Route definitions for the Rooms page.
 * Mounted at '/rooms' in app.js.
 */
const express = require('express');
const router = express.Router();
const roomsController = require('../controllers/rooms');

router.get('/', roomsController.rooms);

module.exports = router;
