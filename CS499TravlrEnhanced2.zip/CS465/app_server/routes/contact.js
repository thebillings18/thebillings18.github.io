/**
 * app_server/routes/contact.js
 * Route definitions for the Contact Us page.
 * Mounted at '/contact' in app.js.
 */
const express = require('express');
const router = express.Router();
const contactController = require('../controllers/contact');

router.get('/', contactController.contact);

module.exports = router;
