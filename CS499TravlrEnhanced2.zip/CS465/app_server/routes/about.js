/**
 * app_server/routes/about.js
 * Route definitions for the About Us page.
 * Mounted at '/about' in app.js.
 */
const express = require('express');
const router = express.Router();
const aboutController = require('../controllers/about');

router.get('/', aboutController.about);

module.exports = router;
