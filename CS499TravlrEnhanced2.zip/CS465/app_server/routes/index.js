/**
 * app_server/routes/index.js
 * Route definitions for the site home page.
 * Mounted at '/' in app.js.
 */
const express = require('express');
const router = express.Router();
const mainController = require('../controllers/main');

router.get('/', mainController.index);

module.exports = router;
