/**
 * app_server/routes/meals.js
 * Route definitions for the Meals page.
 * Mounted at '/meals' in app.js.
 */
const express = require('express');
const router = express.Router();
const mealsController = require('../controllers/meals');

router.get('/', mealsController.meals);

module.exports = router;
