/**
 * app_server/controllers/rooms.js
 * Controller for the customer-facing /rooms page.
 *
 * Room data is static and loaded once from rooms.json at module initialisation.
 */
const fs = require('fs');
const path = require('path');

const roomsData = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/rooms.json'), 'utf8'));

/**
 * GET /rooms
 * Renders the Rooms page with accommodation options from rooms.json.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const rooms = (req, res) => {
    res.render('rooms', {
        title: 'Travlr Getaways - Rooms',
        rooms: roomsData
    });
};

module.exports = {
    rooms
};
