/**
 * app_server/controllers/contact.js
 * Controller for the customer-facing /contact page.
 *
 * Contact details (address, phone, email) are stored in data/contact.json
 * and loaded once at module initialisation. If this data ever needs to become
 * editable at runtime, it should be migrated to a database collection.
 */
const fs = require('fs');
const path = require('path');

const contactData = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/contact.json'), 'utf8'));

/**
 * GET /contact
 * Renders the Contact Us page with office details from contact.json.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const contact = (req, res) => {
    res.render('contact', {
        title: 'Travlr Getaways - Contact Us',
        contact: contactData
    });
};

module.exports = {
    contact
};
