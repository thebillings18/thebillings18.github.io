/**
 * app_server/controllers/about.js
 * Controller for the customer-facing /about page.
 *
 * About page content is stored in data/about.json and loaded once at module
 * initialisation rather than on every request, avoiding repeated disk reads.
 */
const fs = require('fs');
const path = require('path');

// Loaded synchronously at startup — acceptable for static content that does
// not change between requests and does not need database access.
const aboutData = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/about.json'), 'utf8'));

/**
 * GET /about
 * Renders the About Us page with content sourced from about.json.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const about = (req, res) => {
    res.render('about', {
        title: 'Travlr Getaways - About Us',
        aboutContent: aboutData.content
    });
};

module.exports = {
    about
};
