/**
 * app_server/controllers/meals.js
 * Controller for the customer-facing /meals page.
 *
 * Meal data is static and loaded once from meals.json at module initialisation.
 */
const fs = require('fs');
const path = require('path');

const mealsData = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/meals.json'), 'utf8'));

/**
 * GET /meals
 * Renders the Meals page with dining options from meals.json.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const meals = (req, res) => {
    res.render('meals', {
        title: 'Travlr Getaways - Meals',
        meals: mealsData
    });
};

module.exports = {
    meals
};
