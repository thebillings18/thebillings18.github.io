/**
 * app_server/controllers/news.js
 * Controller for the customer-facing /news page.
 *
 * News articles are stored in data/news.json. Using require() here (rather than
 * fs.readFileSync) is intentional — Node caches the parsed JSON after the first
 * load, which is equivalent in performance for static content.
 */
const newsData = require('../../data/news.json');

/**
 * GET /news
 * Renders the News page with articles sourced from news.json.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
module.exports.news = function(req, res) {
    res.render('news', {
        title: 'Latest News',
        articles: newsData
    });
};
