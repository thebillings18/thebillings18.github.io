/**
 * app_server/controllers/travel.js
 * Controller for the customer-facing /travel page.
 *
 * Rather than reading trip data directly from the database, this controller
 * calls the internal REST API (GET /api/trips). This keeps the server-side
 * rendering layer decoupled from Mongoose and ensures both the SPA and the
 * Handlebars views always display the same data from a single source of truth.
 *
 * Note: node-fetch v3 is ESM-only, so it must be imported dynamically inside
 * the function rather than at the top of the file with require().
 */
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

/**
 * GET /travel
 * Fetches all trips from the internal API and renders the travel view.
 * On API failure the page still renders with an error message rather than
 * crashing, so the rest of the site remains accessible.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const travel = async (req, res) => {
    const pageTitle = 'Travlr Getaways - Travel Packages';
    const tripsEndpoint = 'http://localhost:3000/api/trips';

    try {
        const response = await fetch(tripsEndpoint);

        if (!response.ok) {
            throw new Error(`Failed to fetch trips data: ${response.status} ${response.statusText}`);
        }

        const tripsData = await response.json();

        res.render('travel', {
            title: pageTitle,
            trips: tripsData
        });
    } catch (error) {
        // Degrade gracefully — render the page without trip data rather than
        // returning a 500, so navigation and other page content still work.
        console.error("Error fetching trips data:", error.message);
        res.render('travel', {
            title: pageTitle,
            error: 'Failed to load travel packages.'
        });
    }
};

module.exports = {
    travel
};
