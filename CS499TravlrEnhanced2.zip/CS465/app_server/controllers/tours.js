/**
 * app_server/controllers/tours.js
 * Controller for the customer-facing /tours page.
 *
 * Currently renders a static view with no dynamic data. If tour packages are
 * added to the database in a future iteration, this controller should be updated
 * to fetch from the API in the same pattern used by travel.js.
 */

/**
 * GET /tours
 * Renders the Tours page.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const tours = (req, res) => {
    res.render('tours', { 
        title: 'Tours'
    });
};

module.exports = {
    tours
};
