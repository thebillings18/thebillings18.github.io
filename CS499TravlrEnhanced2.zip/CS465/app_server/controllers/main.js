/**
 * app_server/controllers/main.js
 * Controller for the customer-facing home page (/).
 */

/**
 * GET /
 * Renders the site home page.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
exports.index = (req, res) => {
    res.render('index', { title: 'Welcome to Travlr Getaways' });
};
