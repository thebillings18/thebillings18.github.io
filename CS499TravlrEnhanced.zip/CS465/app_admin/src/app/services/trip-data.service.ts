import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { AuthenticationService } from './authentication.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  /** Base URL for the trips API endpoint, sourced from the environment config. */
  url = `${environment.apiBaseUrl}/trips`;

  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) {}

  /**
   * Builds an HttpOptions object containing the Authorization and Content-Type headers
   * required for protected API calls. Reads the JWT from AuthenticationService.
   *
   * @returns {{ headers: HttpHeaders }} Options object ready to pass to HttpClient methods
   */
  private authHeaders(): { headers: HttpHeaders } {
    const token = this.authService.getToken();
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      })
    };
  }

  /**
   * Fetches all trips from the API. No authentication required.
   *
   * @returns {Observable<Trip[]>} Observable that emits an array of Trip objects
   */
  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url);
  }

  /**
   * Fetches a single trip by its unique trip code. No authentication required.
   *
   * @param {string} tripCode - The unique code identifying the trip
   * @returns {Observable<Trip>} Observable that emits the matching Trip object
   */
  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.url}/${tripCode}`);
  }

  /**
   * Creates a new trip. Requires a valid JWT (protected endpoint).
   *
   * @param {Trip} formData - The trip data to submit
   * @returns {Observable<Trip>} Observable that emits the newly created Trip
   */
  addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.url, formData, this.authHeaders());
  }

  /**
   * Updates an existing trip identified by its trip code. Requires a valid JWT.
   *
   * @param {string} tripCode - The unique code of the trip to update
   * @param {Trip}   formData - The updated trip data
   * @returns {Observable<Trip>} Observable that emits the updated Trip
   */
  updateTrip(tripCode: string, formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.url}/${tripCode}`, formData, this.authHeaders());
  }

  /**
   * Deletes a trip identified by its trip code. Requires a valid JWT.
   *
   * @param {string} tripCode - The unique code of the trip to delete
   * @returns {Observable<void>} Observable that completes when the trip is deleted
   */
  deleteTrip(tripCode: string): Observable<void> {
    return this.http.delete<void>(`${this.url}/${tripCode}`, this.authHeaders());
  }
}
