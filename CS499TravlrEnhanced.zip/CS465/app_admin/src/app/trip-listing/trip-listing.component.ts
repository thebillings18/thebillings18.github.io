import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { TripCardComponent } from '../trip-card/trip-card.component'; 
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent], 
  templateUrl: './trip-listing.component.html',
  styleUrls: ['./trip-listing.component.css'],
  providers: [TripDataService],
})
export class TripListingComponent implements OnInit {
  trips: Trip[] = [];
  message: string = '';

  /** True when a valid JWT is present — used to show/hide admin controls in the template. */
  isLoggedIn: boolean = false;

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authService: AuthenticationService
  ) {
    console.log('trip-listing constructor');
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }
  
  public onDelete(tripCode: string): void {
    if (!tripCode) {
      console.error('Delete failed: trip has no code. Re-add the trip with a code value.');
      return;
    }
    this.tripDataService.deleteTrip(tripCode).subscribe({
      next: () => {
        console.log(`Trip with code ${tripCode} deleted successfully.`);
        this.getStuff(); // Refresh the list of trips after deletion
      },
      error: (error: any) => {
        console.error(`Error deleting trip ${tripCode}:`, error);
      }
    });
  }

  private getStuff(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        this.trips = value;
        if (value.length > 0) {
          this.message = `There are ${value.length} trips available.`;
        } else {
          this.message = 'There were no trips retrieved from the database.';
        }
        console.log(this.message);
      },
      error: (error: any) => {
        console.log('Error: ' + error);
      },
    });
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.isLoggedIn = this.authService.isLoggedIn();
    this.getStuff();
  }
}
