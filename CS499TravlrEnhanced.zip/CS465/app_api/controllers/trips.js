const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

/**
 * Allowed fields for trip create/update operations.
 * Acts as an explicit allow-list to prevent mass-assignment of unexpected fields.
 * @type {string[]}
 */
const TRIP_ALLOWED_FIELDS = ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description'];

/**
 * Extracts only the allowed fields from a request body object.
 * Any keys not in TRIP_ALLOWED_FIELDS are silently dropped.
 *
 * @param {object} body - Raw request body from Express
 * @returns {object} Sanitised object containing only permitted fields
 */
const sanitiseTripBody = (body) => {
  return TRIP_ALLOWED_FIELDS.reduce((acc, field) => {
    if (body[field] !== undefined) acc[field] = body[field];
    return acc;
  }, {});
};

/**
 * GET /api/trips
 * Returns all trips from the database.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find();
    res.status(200).json(trips);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * GET /api/trips/:tripCode
 * Returns a single trip matching the given trip code.
 *
 * @param {object} req            - Express request object
 * @param {string} req.params.tripCode - The unique trip code to look up
 * @param {object} res            - Express response object
 */
const tripReadOne = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode });
    if (trip) {
      res.status(200).json(trip);
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * POST /api/trips
 * Creates and saves a new trip. Only allow-listed fields are accepted.
 *
 * @param {object} req      - Express request object
 * @param {object} req.body - Trip data from the request body
 * @param {object} res      - Express response object
 */
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = new Trip(sanitiseTripBody(req.body));
    const trip = await newTrip.save();
    res.status(201).json(trip);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

/**
 * PUT /api/trips/:tripCode
 * Updates an existing trip identified by trip code. Only allow-listed fields are applied.
 *
 * @param {object} req            - Express request object
 * @param {string} req.params.tripCode - The unique trip code to update
 * @param {object} req.body       - Updated trip fields
 * @param {object} res            - Express response object
 */
const tripsUpdateTrip = async (req, res) => {
  try {
    const updatedTrip = await Trip.findOneAndUpdate(
      { code: req.params.tripCode },
      sanitiseTripBody(req.body),
      { new: true, runValidators: true }
    );
    if (updatedTrip) {
      res.status(200).json(updatedTrip);
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

/**
 * DELETE /api/trips/:tripCode
 * Deletes a trip identified by its trip code.
 *
 * @param {object} req            - Express request object
 * @param {string} req.params.tripCode - The unique trip code to delete
 * @param {object} res            - Express response object
 */
const tripsDeleteTrip = async (req, res) => {
  try {
    const deletedTrip = await Trip.findOneAndDelete({ code: req.params.tripCode });
    if (deletedTrip) {
      res.status(204).send();
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(400).json({ message: 'Error deleting trip', error: error.message });
  }
};

/**
 * DELETE /api/trips/id/:id
 * Deletes a trip by its MongoDB ObjectId. Useful for trips that have no trip code.
 *
 * @param {object} req       - Express request object
 * @param {string} req.params.id - The MongoDB _id of the trip to delete
 * @param {object} res       - Express response object
 */
const tripsDeleteById = async (req, res) => {
  try {
    const deletedTrip = await Trip.findByIdAndDelete(req.params.id);
    if (deletedTrip) {
      res.status(204).send();
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  } catch (error) {
    res.status(400).json({ message: 'Error deleting trip', error: error.message });
  }
};

module.exports = {
  tripsList,
  tripReadOne,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip,
  tripsDeleteById,
};
